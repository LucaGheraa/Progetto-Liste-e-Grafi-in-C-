﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Liste_in_C__Gherardi_Luca
{
    public class GraphNode
    {
        private string _value;
        List<GraphNode> _neighbors;
        public GraphNode(string value)
        {
            this._value = value;
            _neighbors = new List<GraphNode>();
        }
        public string Value
        {
            get
            {
                return _value;
            }
        }
        public List<GraphNode> Neighbors
        {
            get
            {
                return _neighbors;
            }
        }
        public bool AddNeighbor(GraphNode neighbor)
        {
            if (_neighbors.Contains(neighbor))
            {
                return false;
            }
            else
            {
                _neighbors.Add(neighbor);
                return true;
            }
        }
        public bool RemoveNeighbor(GraphNode myGraphNode)
        {
            if (_neighbors.Contains(myGraphNode))
            {
                return _neighbors.Remove(myGraphNode);
            }
            return false;
        }
        public bool RemoveAllNeighbor()
        {
            _neighbors.Clear();
            return true;
        }
        public override string ToString()
        {
            StringBuilder nodeString = new StringBuilder();
            nodeString.Append("[Nodo di valore: " + Value + " con vicini:");
            foreach (var item in _neighbors)
            {
                nodeString.Append(" -> " + item.Value);
            }
            nodeString.Append(" ]");
            return nodeString.ToString();
        }
    }

    public class StandardGraph
    {
        List<GraphNode> myGraphNodes = new List<GraphNode>();
        public StandardGraph()
        {

        }
        // Neighbor: Add, Find, Remove, Clear
        public int Count
        {
            get
            {
                return myGraphNodes.Count;
            }
        }
        public IList<GraphNode> GraphNodes
        {
            get
            {
                return myGraphNodes.AsReadOnly();
            }
        }
        public bool AddNode(string value)
        {
            if (Find(value) != null)
            {
                return false;
            }
            else
            {
                myGraphNodes.Add(new GraphNode(value));
                return true;
            }
        }

        public bool AddEdge(string n1, string n2)
        {
            GraphNode gn1 = Find(n1);
            GraphNode gn2 = Find(n2);
            if (gn1 == null || gn2 == null)
            {
                return false;
            }
            else if (gn1.Neighbors.Contains(gn2))
            {
                return false;
            }
            else
            {
                gn1.AddNeighbor(gn2);
                return true;
            }
        }
        public GraphNode Find(string value)
        {
            foreach (GraphNode item in myGraphNodes)
            {
                if (item.Value.Equals(value))
                {
                    return item;
                }
            }
            return null;
        }
        public bool RemoveNode(string value)
        {
            GraphNode TBR = Find(value);
            if (TBR != null)
            {
                myGraphNodes.Remove(TBR);
                foreach (GraphNode item in myGraphNodes)
                {
                    item.RemoveNeighbor(TBR);
                }
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool RemoveEdge(string n1, string n2)
        {
            GraphNode gn1 = Find(n1);
            GraphNode gn2 = Find(n2);
            if (gn1 == null || gn2 == null)
            {
                return false;
            }
            else if (!gn1.Neighbors.Contains(gn2))
            {
                return false;
            }
            else
            {
                gn1.RemoveNeighbor(gn2);
                return true;
            }
        }
        public bool Clear()
        {
            foreach (GraphNode item in myGraphNodes)
            {
                item.RemoveAllNeighbor();
            }
            myGraphNodes.Clear();
            return true;
        }
        public override string ToString()
        {
            StringBuilder nodeString = new StringBuilder();
            nodeString.Append("========================================\r\n");
            nodeString.Append("Standard Graph Lista di Adiacenza:\r\n");
            nodeString.Append("----------------------------------------\r\n");
            for (int i = 0; i < Count; i++)
            {
                nodeString.Append(myGraphNodes[i].ToString());
                nodeString.Append("\r\n");
            }
            nodeString.Append("----------------------------------------\r\n");
            return nodeString.ToString();
        }
        public List<GraphNode> BFS(GraphNode root)
        {
            List<GraphNode> visited = new List<GraphNode>();
            Queue<GraphNode> queue = new Queue<GraphNode>();
            GraphNode currentNode;

            visited.Add(root);
            queue.Enqueue(root);

            while (queue.Count > 0)
            {
                currentNode = queue.Dequeue();

                foreach (GraphNode neighbor in currentNode.Neighbors)
                {
                    if (!visited.Contains(neighbor))
                    {
                        visited.Add(neighbor);
                        queue.Enqueue(neighbor);
                    }
                }
            }
            return visited;
        }
        public List<GraphNode> DFS(GraphNode root)
        {
            List<GraphNode> visited = new List<GraphNode>();
            Stack<GraphNode> stack = new Stack<GraphNode>();
            GraphNode currentNode;

            stack.Push(root);

            while (stack.Count > 0)
            {
                currentNode = stack.Pop();

                if (!visited.Contains(currentNode))
                {
                    visited.Add(currentNode);

                    foreach (GraphNode neighbor in currentNode.Neighbors)
                    {
                        if (!visited.Contains(neighbor))
                        {
                            stack.Push(neighbor);
                        }
                    }
                }
            }
            return visited;
        }
    }
}
