﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Liste_in_C__Gherardi_Luca
{
    public class Importatore
    {
        public List<string> Importa(string filePath)
        {
            List<string> importedList = new List<string>();

            try
            {
                string csvContent = File.ReadAllText(filePath);

                string[] elements = csvContent.Split(',');

                foreach (string element in elements)
                {
                    importedList.Add(element.Trim());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errore durante l'importazione della lista: " + ex.Message);
            }

            return importedList;
        }
    }
}
