﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Liste_in_C__Gherardi_Luca
{
    public class Esportatore
    {
        public void ExportListToCsv(List<string> mialista, string filePath)
        {
            string csvContent = string.Join(",", mialista);

            File.WriteAllText(filePath, csvContent);
        }
    }

}
