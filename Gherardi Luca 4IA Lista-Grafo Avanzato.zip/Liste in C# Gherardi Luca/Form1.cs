﻿using Liste_in_C__Gherardi_Luca;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace Liste_in_C__Gherardi_Luca
{
    public partial class MainForm : Form
    {
        private Lista lista;
        private StandardGraph standardGraph;
        private bool InTestaChecked = false;
        private bool InCodaChecked = false;
        private bool InPosizioneChecked = false;
        private bool EliminaPerValoreChecked = false;
        private bool EliminaInPosizioneChecked = false;

        public MainForm()
        {
            InitializeComponent();
            lista = new Lista();
            standardGraph = new StandardGraph();
            this.MinimumSize = new Size(sogliaMinimaLarghezza, sogliaMinimaAltezza);
        }
        private void AggiornaVisualizzazioneGrafo()
        {
            lbxLista.Text = standardGraph.ToString();
            lbxLista.Items.Clear();
            foreach (var node in standardGraph.GraphNodes)
            {
                lbxLista.Items.Add(node.ToString());
            }
        }
        private void AggiornaVisualizzazione()
        {
            lbxLista.Items.Clear();
            foreach (string valore in lista.GetLista())
            {
                lbxLista.Items.Add(valore);
            }
        }


        private void rbtnIntesta_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            if (radioButton != null)
            {
                InTestaChecked = radioButton.Checked;
            }
        }

        private void rbtnInCoda_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            if (radioButton != null)
            {
                InCodaChecked = radioButton.Checked;
            }
        }

        private void rbtnInPosizione_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            if (radioButton != null)
            {
                InPosizioneChecked = radioButton.Checked;
            }
        }
        private void rbtnEliminaPerValore_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            if (radioButton != null)
            {
                EliminaPerValoreChecked = radioButton.Checked;
            }
        }
        private void rbtnEliminaInPosizione_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            if (radioButton != null)
            {
                EliminaInPosizioneChecked = radioButton.Checked;
            }
        }



      


        private void MainForm_Load(object sender, EventArgs e)
        {

        }
        private void btnNodo_Click(object sender, EventArgs e)
        {
            string nodo = txbNodo.Text;

            if (!string.IsNullOrEmpty(nodo))
            {
                if (standardGraph.AddNode(nodo))
                {
                    AggiornaVisualizzazioneGrafo();
                }
                else
                {
                    MessageBox.Show("Nodo già esistente", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Inserisci un valore valido per il nodo", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminaNodo_Click(object sender, EventArgs e)
        {
            string nodo = txbEliminaNodo.Text;

            if (!string.IsNullOrEmpty(nodo))
            {
                if (standardGraph.RemoveNode(nodo))
                {
                    AggiornaVisualizzazioneGrafo();
                }
                else
                {
                    MessageBox.Show("Nodo non trovato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Inserisci un valore valido per il nodo", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnEdge_Click(object sender, EventArgs e)
        {
            string nodo1String = txbEdge1.Text;
            string nodo2String = txbEdge2.Text;

            if (!string.IsNullOrEmpty(nodo1String) && !string.IsNullOrEmpty(nodo2String))
            {
                if (standardGraph.Find(nodo1String) == null || standardGraph.Find(nodo2String) == null)
                {
                    MessageBox.Show("Entrambi i nodi devono esistere nel grafo per creare un edge", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (standardGraph.Find(nodo1String).Neighbors.Contains(standardGraph.Find(nodo2String)))
                {
                    MessageBox.Show("Edge già esistente", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    standardGraph.AddEdge(nodo1String, nodo2String);
                    AggiornaVisualizzazioneGrafo();
                }
            }
            else
            {
                MessageBox.Show("Inserisci valori validi per i nodi", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnEliminaEdge_Click(object sender, EventArgs e)
        {
            string nodo1String = txbEliminaEdge1.Text;
            string nodo2String = txbEliminaEdge2.Text;

            if (!string.IsNullOrEmpty(nodo1String) && !string.IsNullOrEmpty(nodo2String))
            {
                GraphNode gn1 = standardGraph.Find(nodo1String);
                GraphNode gn2 = standardGraph.Find(nodo2String);

                if (gn1 == null || gn2 == null)
                {
                    MessageBox.Show("Entrambi i nodi devono esistere nel grafo per eliminare un edge", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (!gn1.Neighbors.Contains(gn2))
                {
                    MessageBox.Show("Edge non trovato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    standardGraph.RemoveEdge(nodo1String, nodo2String);
                    AggiornaVisualizzazioneGrafo();
                }
            }
            else
            {
                MessageBox.Show("Inserisci valori validi per i nodi", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private long SommaNodi(GraphNode root)
        {
            long sum = 0;
            List<GraphNode> visited = standardGraph.BFS(standardGraph.GraphNodes[0]);

            foreach (GraphNode n in visited)
            {
                if (int.TryParse(n.Value, out int value))
                {
                    sum += value;
                }
                else
                {
                    Console.WriteLine($"Il valore del nodo '{n.Value}' non può essere convertito in un intero e verrà ignorato durante il calcolo della somma.");
                }
            }
            return sum;
        }



        private void btnSommaGrafo_Click(object sender, EventArgs e)
        {

            MessageBox.Show(this.SommaNodi(standardGraph.GraphNodes[0]).ToString());
        }



        private int sogliaMinimaLarghezza = 900;
        private int sogliaMinimaAltezza = 352;

        private void MainForm_Resize(object sender, EventArgs e)
        {
            if (this.Width < sogliaMinimaLarghezza)
            {
                this.Width = sogliaMinimaLarghezza;
            }

            if (this.Height < sogliaMinimaAltezza)
            {
                this.Height = sogliaMinimaAltezza;
            }
        }
        private void btnBFS_Click(object sender, EventArgs e)
        {
            if (standardGraph.Count > 0)
            {
                List<GraphNode> visitedNodes = standardGraph.BFS(standardGraph.GraphNodes[0]);
                string result = "BFS Visit Order: " + string.Join(", ", visitedNodes.ConvertAll(node => node.Value.ToString()));
                MessageBox.Show(result);
            }
            else
            {
                MessageBox.Show("Il grafo e' vuoto.");
            }
        }
        private void btnDFS_Click(object sender, EventArgs e)
        {
            if (standardGraph.Count > 0)
            {
                List<GraphNode> visitedNodes = standardGraph.DFS(standardGraph.GraphNodes[0]);
                string result = "DFS Visit Order: " + string.Join(", ", visitedNodes.ConvertAll(node => node.Value.ToString()));
                MessageBox.Show(result);
            }
            else
            {
                MessageBox.Show("Il grafo e' vuoto.");
            }
        }

        private void btnInserisci_Click(object sender, EventArgs e)
        {
            if (InTestaChecked)
            {
                string stringa = txbInserisci.Text;
                if (!string.IsNullOrEmpty(stringa))
                {
                    lista.InserisciInTesta(stringa);
                    AggiornaVisualizzazione();
                }
                else
                {
                    MessageBox.Show("Inserisci una stringa valida", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (InCodaChecked)
            {
                string stringa = txbInserisci.Text;
                if (!string.IsNullOrEmpty(stringa))
                {
                    lista.InserisciInCoda(stringa);
                    AggiornaVisualizzazione();
                }
                else
                {
                    MessageBox.Show("Inserisci una stringa valida", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (InPosizioneChecked)
            {
                if (int.TryParse(txbPosizione.Text, out int posizione))
                {
                    try
                    {
                        string stringa = txbInserisci.Text;
                        lista.InserisciInPosizione(stringa, posizione);
                        AggiornaVisualizzazione();
                    }
                    catch (ArgumentOutOfRangeException)
                    {
                        MessageBox.Show("Posizione non valida", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Posizione non valida", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
        }

        private void btnElimina_Click(object sender, EventArgs e)
        {
            if (EliminaPerValoreChecked)
            {
                string stringa = txbInserisci.Text;
                if (!string.IsNullOrEmpty(stringa))
                {
                    lista.CancellaPerValore(stringa);
                    AggiornaVisualizzazione();
                }
                else
                {
                    MessageBox.Show("Inserisci una valore valido", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (EliminaInPosizioneChecked)
            {
                if (int.TryParse(txbPosizione.Text, out int posizione))
                {
                    try
                    {
                        lista.CancellaPerPosizione(posizione);
                        AggiornaVisualizzazione();
                    }
                    catch (ArgumentOutOfRangeException)
                    {
                        MessageBox.Show("Posizione non valida", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Posizione non valida", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void btnEsporta_Click(object sender, EventArgs e)
        {
            List<string> mialista = new List<string>();
            foreach (string item in lbxLista.Items)
            {
                mialista.Add(item);
            }

            string filePath = "Lista.csv";

            Esportatore exporter = new Esportatore();
            exporter.ExportListToCsv(mialista, filePath);

            MessageBox.Show("Lista esportata con successo come file CSV!");
        }
        private void btnImporta_Click(object sender, EventArgs e)
        {
            string filePath = "Lista.csv";

            Importatore importer = new Importatore();

            List<string> importedList = importer.Importa(filePath);

            lbxLista.Items.Clear();
            foreach (string item in importedList)
            {
                lbxLista.Items.Add(item);
            }

            MessageBox.Show("Lista importata con successo dal file CSV!");
        }
        private int ContaNodiDivisibiliPer7()
        {
            int count = 0;
            foreach (GraphNode node in standardGraph.GraphNodes)
            {
                if (int.TryParse(node.Value.ToString(), out int nodeValue) && nodeValue % 7 == 0)
                {
                    count++;
                }
            }
            return count;
        }

        private void MostraNodiDivisibiliPer7()
        {
            int count = ContaNodiDivisibiliPer7();
            MessageBox.Show($"Numero di nodi divisibili per 7: {count}", "Risultato", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void btnNodiDivisibili7_Click(object sender, EventArgs e)
        {
            MostraNodiDivisibiliPer7();
        }
    }
}

