﻿using System;
using System.Collections.Generic;

namespace Liste_in_C__Gherardi_Luca
{
    public class Lista
    {
        private List<string> lista;

        public Lista()
        {
            lista = new List<string>();
        }

        public void InserisciInTesta(string valore)
        {
            lista.Insert(0, valore);
        }

        public void InserisciInCoda(string valore)
        {
            lista.Add(valore);
        }

        public void InserisciInPosizione(string valore, int posizione)
        {
            if (posizione >= 0 && posizione <= lista.Count)
            {
                posizione -= 1;
                lista.Insert(posizione, valore);
            }
            else
            {
                throw new ArgumentOutOfRangeException("Posizione non valida");
            }
        }

        public void CancellaPerPosizione(int posizione)
        {
            if (posizione >= 0 && posizione < lista.Count)
            {
                posizione -= 1;
                lista.RemoveAt(posizione);
            }
            else
            {
                throw new ArgumentOutOfRangeException("Posizione non valida");
            }
        }

        public void CancellaPerValore(string valore)
        {
            if (lista.Contains(valore))
            {
                lista.Remove(valore);
            }
            else
            {
                throw new ArgumentException("Valore non presente nella lista");
            }
        }

        public List<string> GetLista()
        {
            return new List<string>(lista);
        }
    }
}
